# This command fetches python-xkit from Ubuntu's mirror and install it using dpkg
wget http://mirror.pnl.gov/ubuntu//pool/main/x/x-kit/python-xkit_0.4.2.3build1_all.deb && sudo dpkg --install python-xkit_0.4.2.3build1_all.deb && rm python-xkit_0.4.2.3build1_all.deb
# This command fetches jockey-common from Ubuntu's mirror and installs it using dpkg
wget http://mirror.pnl.gov/ubuntu//pool/main/j/jockey/jockey-common_0.9.7-0ubuntu7_all.deb && sudo dpkg --install jockey-common_0.9.7-0ubuntu7_all.deb && rm jockey-common_0.9.7-0ubuntu7_all.deb
